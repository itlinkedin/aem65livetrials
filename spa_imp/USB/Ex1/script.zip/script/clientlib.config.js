module.exports = {
    // default working directory (can be changed per 'cwd' in every asset option)
    context: __dirname,
 
    // path to the clientlib root folder (output)
    clientLibRoot: "./../aem-app/jcr_root/apps/we-spa/clientlibs",
 
    libs: {
        name: "react-app",
        allowProxy: true,
        categories: ["we-spa.react"],
        serializationFormat: "xml",
        jsProcessor: ["min:gcc"],
        dependencies:["we-spa.grid"],
        assets: {
            js: [
                "build/static/**/*.js"
            ],
            css: [
                "build/static/**/*.css"
            ]
        }
    }
};
