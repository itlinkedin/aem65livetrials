#!/bin/bash

echo "**** Step 3.2 Installing create-react-app NPM Module ****"
npm install -g create-react-app

echo "**** Step 3.3 Creating Sample React App ****"
create-react-app react-app

echo "**** Step 3.4 Going Inside React App ****"
cd react-app

echo "**** Step 4.1 Installing aem-clientlib-generator ****"
npm install --save-dev aem-clientlib-generator

echo "**** Going to React App Folder ****"
cd ..

echo "**** Step 4.2 Copying clientlib.config.js to react-app ****"
cp -f clientlib.config.js react-app/

echo "**** Step 4.3. Updating package.json in react-app ****"
cp -f package.json react-app/

echo "**** Step 6.1 Installing  AEMFED ****"
sudo npm install aemfed -g

echo "****Step 6.2 Running AEMFED"
aemfed -t "http://admin:admin@localhost:4502" -w "./aem-app/jcr_root"

echo "**** Step7.1 Running Build ****"
cd react-app
npm run build

echo "**** Process Complete ****"
